/*
    Name: Patrick Daniel
    Pawprint: phd6x2
    Date: 4/1/2015
    Lab section: G
    Sub code: Queue
    CS2050 Lab8
*/

#include "queue.h"
#define MAX_STR_LEN 20

/*enqueues the given value into the queue*/
void enqueue(queue** head, char* name)
{
	
}

/*this function will dequeue and free the next node in the queue and return its stored value*/
char dequeue(queue** head)
{
	
}

/*this function frees al the nodes in the queue*/
void free_queue(queue* head)
{
	
}